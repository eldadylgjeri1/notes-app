# notes-app
 A tool which helps you when you need to take a quick note to make a shopping list, reminder for an address, or a startup idea
 A simple organizer. 
